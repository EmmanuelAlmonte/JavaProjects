package occupation;

public class Main {
    // start of class Main. 
    public static void main(String[] args) {
        // start of main().
        // Created an instance of Occupation and named it first Occupation.
        Occupation firstOccupation = new Occupation();// uses the constructor Occupation() with no parameters.
        firstOccupation.setOcc("11-1011");// sets the Occupation code.
        firstOccupation.setTitle("Chief Executive");// Sets the title for Occupation.
        firstOccupation.setEmployed(205890);// Sets the amount of employed in this occupation.
        firstOccupation.setHourly(93.20);// sets the hourly rate for this Occupation.
        firstOccupation.setAnnual(193850);// Sets the annual salary for this Occupation.
        System.out.println(firstOccupation.toString());// Displays all of the properties in the instance of firstOccupation.
    }//end of main().

}//end of class main.
