package occupation;


public class Main {
    // start of class Main. 
    public static void main(String[] args) throws Exception {
        // start of main().
        // Created an instance of Occupation and named it first OccupationList.
        OccupationList firstList = new OccupationList();

        // store the data.
        firstList.storeOccupation();

        // display data.
        firstList.displayData();

        // Search list of occupation.
        firstList.searchList();
    }//end of main().

}//end of class main.
