package com.example.helloworld;


/*
* Hello world Application
* Created for CSCI 112
* Last modified July 17, 2021
* by Emmanuel Almonte
*/



public class HelloWorld {
   /*
   main method prints message on the screen. 
   */ 
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }// end main()

}// end class HelloWorld